import { stringParaEntradaDePreco } from "@/utils/converters";


export default class Produto {
    id: number | null;
    nome: string;
    preco: number;
    qtdEstoque: string;
    descricao: string;
    status: string;
    constructor(id: number | null, nome: string, preco: number, qtdEstoque: string, descricao: string, status: string) { 

    this.id = id;
    this.nome = nome;
    this.preco = preco;
    this.qtdEstoque = qtdEstoque;
    this.descricao = descricao;
    this.status = status;
    }


 /*   
    static geraProdutosMock() {
        return [
            new Produto(1, "Teste 1", "12.00", "59", "palavras", "PREVISTO"),
            new Produto(2, "Testou 2", "1000.00", "38", "frase", "PREVISTO")
        ];
    }
*/

/*
    static vazio(): Produto {
        return new Produto(null, "", stringParaEntradaDePreco(""), "", "", "");
       }
 */      
       static vazio(): Produto {
        return new Produto(null, "", 0, "", "", ""); // Exemplo de inicialização com valores padrão
      }
    }



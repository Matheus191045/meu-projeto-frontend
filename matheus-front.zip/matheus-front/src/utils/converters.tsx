export function stringParaEntradaDePreco (preco: string) {
    if (preco) {
    return new Date(preco).toISOString().split('T')[0]
    }
    return new Date().toISOString().split('T')[0]

    //problema data

   }




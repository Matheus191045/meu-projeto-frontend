import axios from 'axios';
import Produto from '../core/Produto';

interface ApiResponse {
    content: Produto[];
}

const BASE_URL = 'http://localhost:8080';

export const fetchProdutos = async (): Promise<Produto[]> => {
    try {
        const response = await axios.get<ApiResponse>(`${BASE_URL}/produtos`);
        return response.data.content;
    } catch (error) {
        throw new Error('Erro ao buscar produtos');
    }
};

export const cadastrarProduto = async (produto: Produto): Promise<Produto> => {
    try {
        const response = await axios.post<Produto>(`${BASE_URL}/produtos`, produto);
        return response.data;
    } catch (error) {
        console.error("Erro ao cadastrar produto:", error);
        throw error;
    }
};

export const atualizarProduto = async (produto: Produto): Promise<Produto> => {
    try {
        const response = await axios.put<Produto>(
            `${BASE_URL}/produtos/${produto.id}`, produto);
        return response.data;
    } catch (error) {
        console.error("Erro ao atualizar produto:", error);
        throw error;
    }
};



export const excluirProduto = async (id: number): Promise<void> => {
    try {
        await axios.delete(`${BASE_URL}/produtos/${id}`);
    } catch (error) {
        console.error("Erro ao excluir produto:", error);
        throw error;
    }
};




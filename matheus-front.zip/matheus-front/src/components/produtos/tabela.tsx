import Produto from "@/core/Produto"
import { IconeEdicao, IconeLixo } from "../icones/tabela"


interface TabelaProps {
  produtos: Produto[]
  produtoSelecionado?: (produto: Produto) => void
  produtoExcluido?: (produto: Produto) => void
  exibirAcoes?: boolean; // Adicione 
}

function formatarPreco(preco: number): string {
  const formatoPreco = new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
  return formatoPreco.format(preco);
}





export default function Tabela(props: TabelaProps) {


  function renderHeader() {
    return (
      <tr>
        <th className="text-left p-3">id</th>
        <th className="text-left p-3">nome</th>
        <th className="text-left p-3">preco</th>
        <th className="text-left p-3">Quantidade</th>
        <th className="text-left p-3">descricao</th>
        <th className="text-left p-3">status</th>
        {<th className="p-3">Ações</th>}
      </tr>
    )
  }

  function renderDados() {
    return props.produtos?.map((produto, i) => {
      return (
        <tr key={produto.id} className={`${i % 2 === 0 ? 'bg-indigo-200' : 'bg-indigo-100'} `}>
          <td className="text-left p-3">{produto.id}</td>
          <td className="text-left p-3">{produto.nome}</td>
          <td className="text-left p-3">{formatarPreco(produto.preco)}</td>
          <td className="text-left p-3">{produto.qtdEstoque}</td>
          <td className="text-left p-3">{produto.descricao}</td>
          <td className="text-left p-3">{produto.status}</td>
          {renderizarAcoes(produto)}
        </tr>
      );
    });
  }

  function renderizarAcoes(produto: Produto) {
    return (
      <td className="flex justify-center">

        {props.produtoSelecionado
          ? (<button onClick={() => props.produtoSelecionado?.(produto)}
            className={`flex justify-center items text-green-600
    rounded-full p-2 m-1 hover:bg-gray-100`}>{IconeEdicao}</button>)
          : false}

        {props.produtoExcluido
          ? (<button onClick={() => props.produtoExcluido?.(produto)}
            className={`flex justify-center items text-red-600
    rounded-full p-2 m-1 hover:bg-gray-100`}>{IconeLixo}</button>)
          : false}
      </td>)
  }




  return (
    <table className="w-full rounded-xl overflow-hidden">
      <thead className={`text-gray-100
    bg-gradient-to-r from-indigo-500 to-indigo-800`}>
        {renderHeader()}
      </thead>
      <tbody>
        {renderDados()}
      </tbody>
    </table>
  )

}




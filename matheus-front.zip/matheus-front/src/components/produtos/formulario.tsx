import Produto from "@/core/Produto";
import Entrada from "./entrada";
import { useState } from "react";
//import { stringParaEntradaDePreco } from "@/utils/converters" ;
import Botao from "./botao";


interface FormularioProps {
  produto: Produto
  produtoMudou?: (produto: Produto) => void
  cancelado?: () => void
}

const formatarPreco = (preco: number): string => {
  const formattedPrice = preco.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
  return formattedPrice;
};


export default function Formulario(props: FormularioProps) {
  const id = props.produto?.id
  const [nome, setNome] = useState(props.produto?.nome)
  const [preco, setPreco] = useState(props.produto?.preco)
  const [qtdEstoque, setQtdEstoque] = useState(props.produto?.qtdEstoque);
  const [descricao, setDescricao] = useState(props.produto?.descricao)
  const [status, setStatus] = useState(props.produto?.status)

  return (<div>
    {id ? (<Entrada texto="id" valor={id} somenteLeitura ></Entrada>) : false}
    <Entrada texto="Nome" valor={nome} onChange={setNome}></Entrada>
    <Entrada texto="Preco" tipo="number" valor={preco} onChange={(valor) => setPreco(Number(valor))}></Entrada>
    <p>{formatarPreco(preco)}</p>
    <Entrada
      texto="Qtd Estoque"
      tipo="number"
      valor={qtdEstoque}
      onChange={setQtdEstoque}
    ></Entrada>
    <Entrada texto="Descricao" valor={descricao} onChange={setDescricao}></Entrada>
    
    <Entrada texto="Status" valor={status} onChange={setStatus}></Entrada>



    <div className="flex justify-end mt-5" >

      <Botao className="mr-3" cor="bg-gradient-to-r from-blue-500 to-blue-700"
        onClick={() => props.produtoMudou?.(new Produto(id, nome, preco, qtdEstoque, descricao, status))}>
        {id ? 'Alterar' : 'Salvar'}
      </Botao>
      <Botao cor="bg-gradient-to-r from-gray-500 to-gray-700" onClick={props.cancelado}>
        Cancelar
      </Botao>
    </div>
  </div>
  )

}










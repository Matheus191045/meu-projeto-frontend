'use client';

import Botao from "@/components/produtos/botao";
import Layout from "@/components/produtos/layout";
import Tabela from "@/components/produtos/tabela";
import Produto from "@/core/Produto";
import Formulario from "@/components/produtos/formulario";
import { useEffect, useState } from "react";
import { atualizarProduto, cadastrarProduto, excluirProduto, fetchProdutos } from "@/service/produtoService";



export default function Produtos() {

   //const produtos = Produto.geraProdutosMock()

  
const [visivel, setVisivel] = useState<'tabela' | 'form'>('tabela')
const [produto, setProduto] = useState<Produto>(Produto.vazio())

const [produtos, setProdutos] = useState<Produto[]>([]);
useEffect(() => {
 if (visivel === 'tabela') {
 const loadProdutos = async () => {
 try { const dados = await fetchProdutos();
 setProdutos(dados);
 } catch (error) {
 console.error("Erro ao buscar produtos:", error);
 }}
 loadProdutos();
 } }, [visivel]);


   function produtoSelecionado(produto: Produto) {
      //console.log(produto.nome) 
      setProduto(produto)
      setVisivel('form')
   }


   /*
   function produtoExcluido(produto: Produto) {
      console.log(produto.nome)
   }
*/

async function salvarProduto(produto: Produto) {
   try {
    const novoProduto = await cadastrarProduto(produto);
    setVisivel("tabela");
    } catch (error) {
    console.error("Erro ao salvar produto:", error);
    }
   }
   







   function novoProduto() {
      setProduto(Produto.vazio())
      setVisivel("form")
   }

/*
   async function alterarProduto(produto: Produto) {
      try {
         console.log("Alterar Produto:", produto);
         const produtoAtualizado = await atualizarProduto(produto);
         console.log("Produto Atualizado:", produtoAtualizado);

         setProdutos(prevProdutos =>
         prevProdutos.map(p => (p.id === produtoAtualizado.id ? produtoAtualizado : p))
      );

      setProduto(produtoAtualizado);
      setVisivel("tabela");
   } catch (error) {
      console.error("Erro ao atualizar produto:", error);
   }
}

*/

async function alterarProduto(produto: Produto) {
   try {
   const produtoAtualizado = await atualizarProduto(produto);
   setVisivel("tabela");
   } catch (error) {
   console.error("Erro ao atualizar produto:", error);
   }
  }






   function salvarOuAlterarProduto(produto: Produto) {
      
      if (produto.id) {
         alterarProduto(produto)
      } else {
         salvarProduto(produto)
      }
   }




   async function produtoExcluido(produto: Produto) {
      const confirmacao =
         window.confirm("Tem certeza de que deseja excluir este produto?");
      if (confirmacao) {
         try {
            if (produto.id !== null) {
               await excluirProduto(produto.id);
            } else {
               console.error("produtoId é null!");
            }
            setProdutos(prevProdutos => prevProdutos.filter(ev => ev.id !== produto.id));
         } catch (error) {
            console.error("Erro ao excluir produto:", error);
         }
      }
   }



   return (
      <div className={`
         flex justify-center items-center h-screen
         bg-gradient-to-bl from-indigo-900 via-indigo-400 to-indigo-900
         text-white`}>

         <Layout titulo="Estoque de produto">
            {visivel === 'tabela' ? (
               <> <div className="flex justify-end">
                  <Botao className="mb-4" cor="bg-gradient-to-r from-green-500 to-green-700"

                   //onClick={() => setVisivel('form')}>
                   onClick={() => novoProduto()}>
                   

                     Novo produto </Botao>
               </div>
                  <Tabela produtos={produtos}
                     produtoSelecionado={produtoSelecionado}
                     produtoExcluido={produtoExcluido}></Tabela>
               </>
            ) : (<Formulario produto={produto }
               produtoMudou={salvarProduto}
               cancelado={() => setVisivel('tabela')} />)}
         </Layout>
      </div>
   )
}








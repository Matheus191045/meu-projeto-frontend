// Home.js
import canoni from '@/Images/canoni.jpg';
import cuco_ouro from '@/Images/cuco_ouro.jpg';
import appi from '@/Images/appi.jpg';
import img_mountains from '@/Images/img_mountains.jpg';
import React from 'react';
// import './styles.css';

export default function Home() {
  return (
    <div className="container">
      <div className="header">
        <h2 className="title">Site de Produto</h2>
      </div>

      <div>
        <h2>Galeria de imagens</h2>
        <h4>A venda de materiais importados em site e orçamento de preço:</h4>
        <div className="responsive">
          <div className="gallery">
            <a target="_blank">
              <img src="@/Images/canoni.jpg" alt="canon" width="600" height="710" />
            </a>
          </div>
        </div>

        <div className="responsive">
          <div className="gallery">
            <a target="_blank">
              <img src={cuco_ouro} alt="Relogio Cuco" width="600" height="710" />
            </a>       
          </div>
        </div>

        <div className="responsive">
          <div className="gallery">
            <a target="_blank">
              <img src="appi.jpg" alt="Iphone" width="600" height="710" />
            </a>
          </div>
        </div>

        <div className="responsive">
          <div className="gallery">
            <a target="_blank">
              <img src="img_mountains.jpg" alt="Mountains" width="600" height="710" />
            </a>
          </div>
        </div>

        <div className="clearfix"></div>

        <div style={{ padding: '6px' }}>
          <p>
            Descubra o mundo em cada detalhe! Explore nossa coleção exclusiva de materiais importados, trazendo qualidade e estilo internacional para a sua porta. Transforme sua experiência de compra com produtos únicos que refletem o melhor de diferentes culturas. (100%).
          </p>
          <p>Oferta Especial: Compre 2 ou mais produtos e ganhe 10% de desconto no total da compra! Frete grátis para pedidos acima de R$ 200,00.</p>
        </div>
      </div>
    </div>
  );
}



